#pragma once

namespace kvf::vma {
class Image;
class Buffer;
} // namespace kvf::vma
